import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { v4 as uuidv4 } from 'uuid';
import { addDays, addWeeks, addMonths, format } from 'date-fns';

export type Priority = 'high' | 'medium' | 'low';
export type Recurrence = 'none' | 'daily' | 'weekly' | 'monthly';

export interface Category {
  id: string;
  name: string;
  color: string;
}

export interface Task {
  id: string;
  title: string;
  description?: string;
  date: string; // ISO date string YYYY-MM-DD
  time?: string; // HH:mm
  completed: boolean;
  priority: Priority;
  categoryId: string;
  recurrence: Recurrence;
  archived: boolean;
  notificationTime?: string; // HH:mm
}

export interface Settings {
  notificationsEnabled: boolean;
  notificationSound: string;
  defaultTime: string;
  theme: 'light' | 'dark' | 'colorful';
  username: string;
  avatarUrl?: string;
}

interface AppState {
  tasks: Task[];
  categories: Category[];
  settings: Settings;
  
  // Actions
  addTask: (task: Omit<Task, 'id' | 'completed' | 'archived'>) => void;
  updateTask: (id: string, updates: Partial<Task>) => void;
  toggleTask: (id: string) => void;
  deleteTask: (id: string) => void;
  archiveTask: (id: string) => void;
  
  addCategory: (category: Omit<Category, 'id'>) => void;
  deleteCategory: (id: string) => void;
  
  updateSettings: (updates: Partial<Settings>) => void;
}

const DEFAULT_CATEGORIES: Category[] = [
  { id: '1', name: 'Trabalho', color: '#3B82F6' }, // Blue
  { id: '2', name: 'Estudos', color: '#F59E0B' }, // Amber
  { id: '3', name: 'Casa', color: '#10B981' },   // Emerald
  { id: '4', name: 'Projeto', color: '#8B5CF6' }, // Violet
];

const DEFAULT_SETTINGS: Settings = {
  notificationsEnabled: true,
  notificationSound: 'default',
  defaultTime: '09:00',
  theme: 'light',
  username: 'Estudante',
};

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      tasks: [],
      categories: DEFAULT_CATEGORIES,
      settings: DEFAULT_SETTINGS,

      addTask: (taskData) => set((state) => ({
        tasks: [...state.tasks, { 
          ...taskData, 
          id: uuidv4(), 
          completed: false, 
          archived: false 
        }]
      })),

      updateTask: (id, updates) => set((state) => ({
        tasks: state.tasks.map((t) => t.id === id ? { ...t, ...updates } : t)
      })),

      toggleTask: (id) => set((state) => {
        const task = state.tasks.find((t) => t.id === id);
        if (!task) return {};

        // Handle recurrence logic when completing
        if (!task.completed && task.recurrence !== 'none') {
          const nextDate = new Date(task.date);
          let nextDateStr = task.date;

          if (task.recurrence === 'daily') nextDateStr = format(addDays(nextDate, 1), 'yyyy-MM-dd');
          if (task.recurrence === 'weekly') nextDateStr = format(addWeeks(nextDate, 1), 'yyyy-MM-dd');
          if (task.recurrence === 'monthly') nextDateStr = format(addMonths(nextDate, 1), 'yyyy-MM-dd');

          const nextTask: Task = {
            ...task,
            id: uuidv4(),
            date: nextDateStr,
            completed: false,
            archived: false
          };
          
          return {
            tasks: [...state.tasks.map(t => t.id === id ? { ...t, completed: true } : t), nextTask]
          };
        }

        return {
          tasks: state.tasks.map((t) => t.id === id ? { ...t, completed: !t.completed } : t)
        };
      }),

      deleteTask: (id) => set((state) => ({
        tasks: state.tasks.filter((t) => t.id !== id)
      })),

      archiveTask: (id) => set((state) => ({
        tasks: state.tasks.map((t) => t.id === id ? { ...t, archived: true } : t)
      })),

      addCategory: (category) => set((state) => ({
        categories: [...state.categories, { ...category, id: uuidv4() }]
      })),

      deleteCategory: (id) => set((state) => ({
        categories: state.categories.filter((c) => c.id !== id)
      })),

      updateSettings: (updates) => set((state) => ({
        settings: { ...state.settings, ...updates }
      })),
    }),
    {
      name: 'agenda-app-storage',
    }
  )
);
