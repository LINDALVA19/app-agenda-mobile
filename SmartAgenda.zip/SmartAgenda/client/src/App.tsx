import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { BottomNav } from "@/components/BottomNav";
import { TaskForm } from "@/components/TaskForm";

import Home from "@/pages/Home";
import Tasks from "@/pages/Tasks";
import History from "@/pages/History";
import Settings from "@/pages/Settings";
import Calendar from "@/pages/Calendar"; // Import new page
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/tasks" component={Tasks} />
      <Route path="/calendar" component={Calendar} /> 
      <Route path="/history" component={History} />
      <Route path="/settings" component={Settings} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="max-w-md mx-auto bg-background min-h-screen relative shadow-2xl overflow-hidden border-x border-border/20">
          <Router />
          <BottomNav />
          <TaskForm />
          <Toaster />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
