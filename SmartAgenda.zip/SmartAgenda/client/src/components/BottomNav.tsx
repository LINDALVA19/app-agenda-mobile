import { Link, useLocation } from "wouter";
import { Home, CheckSquare, Archive, Settings, Calendar, Plus } from "lucide-react";
import { cn } from "@/lib/utils";

export function BottomNav() {
  const [location] = useLocation();

  // Hidden on Splash/Landing style home if we were doing that, but sticking to persistent nav for usability
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-card/95 backdrop-blur-lg border-t border-border pb-safe pt-2 px-4 z-50 shadow-[0_-5px_20px_rgba(0,0,0,0.2)]">
      <div className="flex items-center justify-between max-w-md mx-auto h-16">
        <Link href="/">
          <a className={cn("flex flex-col items-center justify-center w-14 gap-1 transition-colors", location === "/" ? "text-primary" : "text-muted-foreground hover:text-foreground")}>
            <Home size={22} strokeWidth={location === "/" ? 2.5 : 2} />
            <span className="text-[10px] font-medium">Início</span>
          </a>
        </Link>

        <Link href="/calendar">
          <a className={cn("flex flex-col items-center justify-center w-14 gap-1 transition-colors", location === "/calendar" ? "text-primary" : "text-muted-foreground hover:text-foreground")}>
            <Calendar size={22} strokeWidth={location === "/calendar" ? 2.5 : 2} />
            <span className="text-[10px] font-medium">Agenda</span>
          </a>
        </Link>

        {/* FAB - Floating Action Button */}
        <div className="relative -top-6">
            <button 
              className="flex items-center justify-center w-14 h-14 rounded-full bg-primary text-primary-foreground shadow-glow hover:scale-105 transition-transform active:scale-95 border-4 border-background"
              onClick={() => document.dispatchEvent(new CustomEvent('open-add-task'))}
            >
              <Plus size={26} strokeWidth={3} />
            </button>
        </div>

        <Link href="/history">
          <a className={cn("flex flex-col items-center justify-center w-14 gap-1 transition-colors", location === "/history" ? "text-primary" : "text-muted-foreground hover:text-foreground")}>
            <Archive size={22} strokeWidth={location === "/history" ? 2.5 : 2} />
            <span className="text-[10px] font-medium">Histórico</span>
          </a>
        </Link>

        <Link href="/settings">
          <a className={cn("flex flex-col items-center justify-center w-14 gap-1 transition-colors", location === "/settings" ? "text-primary" : "text-muted-foreground hover:text-foreground")}>
            <Settings size={22} strokeWidth={location === "/settings" ? 2.5 : 2} />
            <span className="text-[10px] font-medium">Ajustes</span>
          </a>
        </Link>
      </div>
    </div>
  );
}
