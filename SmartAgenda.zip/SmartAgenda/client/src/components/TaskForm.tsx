import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { CalendarIcon, Clock, Bell, Flag, Repeat, Tag } from "lucide-react";

import { useStore, Priority, Recurrence } from "@/lib/store";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerFooter,
  DrawerClose,
} from "@/components/ui/drawer";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Switch } from "@/components/ui/switch";

const formSchema = z.object({
  title: z.string().min(1, "O título é obrigatório"),
  description: z.string().optional(),
  date: z.date(),
  time: z.string().optional(),
  notificationTime: z.string().optional(),
  categoryId: z.string().min(1, "Selecione uma categoria"),
  priority: z.enum(["high", "medium", "low"]),
  recurrence: z.enum(["none", "daily", "weekly", "monthly"]),
});

export function TaskForm() {
  const [open, setOpen] = useState(false);
  const { addTask, categories, settings } = useStore();

  useEffect(() => {
    const handleOpen = () => setOpen(true);
    document.addEventListener('open-add-task', handleOpen);
    return () => document.removeEventListener('open-add-task', handleOpen);
  }, []);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      date: new Date(),
      time: settings.defaultTime,
      notificationTime: "",
      categoryId: categories[0]?.id || "",
      priority: "medium",
      recurrence: "none",
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    addTask({
      ...values,
      date: format(values.date, "yyyy-MM-dd"),
      description: values.description || undefined,
      time: values.time || undefined,
      notificationTime: values.notificationTime || undefined,
    });
    form.reset();
    setOpen(false);
  }

  return (
    <Drawer open={open} onOpenChange={setOpen}>
      <DrawerContent className="max-h-[96vh]">
        <div className="mx-auto w-full max-w-md">
          <DrawerHeader>
            <DrawerTitle>Nova Tarefa</DrawerTitle>
          </DrawerHeader>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="px-4 space-y-4 overflow-y-auto max-h-[70vh] pb-safe">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Input placeholder="O que precisa ser feito?" className="text-lg font-medium border-0 px-0 shadow-none focus-visible:ring-0 placeholder:text-muted-foreground/50" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="date"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel className="text-xs text-muted-foreground">Data</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "w-full pl-3 text-left font-normal h-10",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "P")
                              ) : (
                                <span>Escolha uma data</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            disabled={(date) =>
                              date < new Date(new Date().setHours(0, 0, 0, 0))
                            }
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="time"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs text-muted-foreground">Horário</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Input type="time" className="h-10" {...field} />
                          <Clock className="absolute right-3 top-3 h-4 w-4 opacity-50 pointer-events-none" />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="categoryId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs text-muted-foreground">Categoria</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="h-10">
                            <SelectValue placeholder="Selecione" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {categories.map((category) => (
                            <SelectItem key={category.id} value={category.id}>
                              <div className="flex items-center gap-2">
                                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: category.color }} />
                                {category.name}
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="priority"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs text-muted-foreground">Prioridade</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="h-10">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="high" className="text-red-500">Alta</SelectItem>
                          <SelectItem value="medium" className="text-amber-500">Média</SelectItem>
                          <SelectItem value="low" className="text-blue-500">Baixa</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="recurrence"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs text-muted-foreground">Repetição</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="h-10">
                           <div className="flex items-center gap-2">
                              <Repeat size={14} />
                              <SelectValue />
                           </div>
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="none">Não repetir</SelectItem>
                        <SelectItem value="daily">Todo dia</SelectItem>
                        <SelectItem value="weekly">Toda semana</SelectItem>
                        <SelectItem value="monthly">Todo mês</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="flex items-center justify-between bg-muted/30 p-3 rounded-lg border">
                <div className="space-y-0.5">
                  <FormLabel className="text-sm font-medium">Notificação</FormLabel>
                  <p className="text-xs text-muted-foreground">Alertar no horário definido</p>
                </div>
                 <FormField
                  control={form.control}
                  name="notificationTime"
                  render={({ field }) => (
                    <div className="flex items-center gap-2">
                      {field.value && (
                         <Input 
                          type="time" 
                          className="h-8 w-24 text-xs" 
                          value={field.value} 
                          onChange={field.onChange}
                        />
                      )}
                      <Switch
                        checked={!!field.value}
                        onCheckedChange={(checked) => {
                          if (checked) {
                             // Default to task time or current time
                             field.onChange(form.getValues('time') || format(new Date(), 'HH:mm'));
                          } else {
                            field.onChange("");
                          }
                        }}
                      />
                    </div>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Textarea placeholder="Adicionar detalhes..." className="resize-none" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button type="submit" className="w-full h-12 text-base mt-4">Salvar Tarefa</Button>
              <div className="h-8" /> 
            </form>
          </Form>
        </div>
      </DrawerContent>
    </Drawer>
  );
}
