import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { motion } from "framer-motion";
import { Check, Clock, Bell, Repeat } from "lucide-react";
import { cn } from "@/lib/utils";
import { Task, useStore, Priority } from "@/lib/store";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";

interface TaskCardProps {
  task: Task;
}

const priorityColors: Record<Priority, string> = {
  high: "text-red-500 bg-red-50 dark:bg-red-950/30 border-red-200 dark:border-red-900",
  medium: "text-amber-500 bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-900",
  low: "text-blue-500 bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-900",
};

export function TaskCard({ task }: TaskCardProps) {
  const { toggleTask, categories } = useStore();
  const category = categories.find((c) => c.id === task.categoryId);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      whileTap={{ scale: 0.98 }}
    >
      <Card className={cn(
        "p-4 flex items-start gap-3 transition-all border-l-4 shadow-sm hover:shadow-md",
        task.completed ? "opacity-60 bg-muted/50" : "bg-card",
      )}
      style={{ borderLeftColor: category?.color || "hsl(var(--primary))" }}
      >
        <Checkbox 
          checked={task.completed} 
          onCheckedChange={() => toggleTask(task.id)}
          className="mt-1 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground"
        />
        
        <div className="flex-1 min-w-0 gap-1 flex flex-col">
          <div className="flex items-start justify-between gap-2">
            <h3 className={cn(
              "font-medium leading-none truncate transition-all text-base",
              task.completed && "line-through text-muted-foreground"
            )}>
              {task.title}
            </h3>
          </div>
          
          {task.description && (
            <p className="text-xs text-muted-foreground line-clamp-2 mt-1">
              {task.description}
            </p>
          )}

          <div className="flex flex-wrap items-center gap-2 mt-2">
            <Badge variant="outline" className={cn("text-[10px] px-1.5 py-0 h-5 border-0 font-normal", priorityColors[task.priority])}>
              {task.priority === 'high' ? 'Alta' : task.priority === 'medium' ? 'Média' : 'Baixa'}
            </Badge>

            {task.time && (
              <div className="flex items-center text-[10px] text-muted-foreground bg-muted px-1.5 py-0.5 rounded-sm">
                <Clock size={10} className="mr-1" />
                {task.time}
              </div>
            )}

            {task.notificationTime && (
               <div className="flex items-center text-[10px] text-muted-foreground bg-muted px-1.5 py-0.5 rounded-sm">
                <Bell size={10} className="mr-1" />
                {task.notificationTime}
              </div>
            )}

            {task.recurrence !== 'none' && (
               <div className="flex items-center text-[10px] text-primary bg-primary/10 px-1.5 py-0.5 rounded-sm">
                <Repeat size={10} className="mr-1" />
                {task.recurrence === 'daily' ? 'Todo dia' : task.recurrence === 'weekly' ? 'Semanal' : 'Mensal'}
              </div>
            )}
          </div>
        </div>
      </Card>
    </motion.div>
  );
}
