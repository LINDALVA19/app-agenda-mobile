import { useStore } from "@/lib/store";
import { TaskCard } from "@/components/TaskCard";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { motion } from "framer-motion";
import { Search, Filter } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function Tasks() {
  const { tasks } = useStore();
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");

  const filteredTasks = tasks.filter((task) => {
    if (task.archived) return false;
    if (search && !task.title.toLowerCase().includes(search.toLowerCase())) return false;
    if (filter === "all") return true;
    if (filter === "high" && task.priority === "high") return true;
    if (filter === "medium" && task.priority === "medium") return true;
    if (filter === "low" && task.priority === "low") return true;
    // Add category filtering logic here if needed
    return true;
  });

  return (
    <div className="min-h-screen bg-background pb-24 px-6 pt-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Minhas Tarefas</h1>
        <div className="text-sm text-muted-foreground font-medium">
          {filteredTasks.length} tarefas
        </div>
      </div>

      <div className="flex gap-2 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Buscar tarefas..." 
            className="pl-9 bg-muted/50 border-0 shadow-none"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="icon" className="shrink-0 border-0 bg-muted/50">
              <Filter className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Filtrar por</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuRadioGroup value={filter} onValueChange={setFilter}>
              <DropdownMenuRadioItem value="all">Todas</DropdownMenuRadioItem>
              <DropdownMenuRadioItem value="high">Alta Prioridade</DropdownMenuRadioItem>
              <DropdownMenuRadioItem value="medium">Média Prioridade</DropdownMenuRadioItem>
              <DropdownMenuRadioItem value="low">Baixa Prioridade</DropdownMenuRadioItem>
            </DropdownMenuRadioGroup>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="space-y-3">
        {filteredTasks.length === 0 ? (
          <div className="text-center py-12 opacity-50">
            <p>Nenhuma tarefa encontrada</p>
          </div>
        ) : (
          filteredTasks.map((task) => (
            <TaskCard key={task.id} task={task} />
          ))
        )}
      </div>
    </div>
  );
}
