import { useStore } from "@/lib/store";
import { TaskCard } from "@/components/TaskCard";
import { ArrowLeft, Trash2 } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function History() {
  const { tasks, deleteTask } = useStore();
  
  // Get archived or old completed tasks
  const historyTasks = tasks.filter((task) => task.archived || (task.completed && new Date(task.date) < new Date()));

  return (
    <div className="min-h-screen bg-background pb-24 px-6 pt-8">
      <div className="flex items-center gap-3 mb-6">
        <h1 className="text-2xl font-bold">Histórico</h1>
      </div>

      <div className="space-y-3">
        {historyTasks.length === 0 ? (
          <div className="text-center py-12 opacity-50">
            <p>Nenhuma tarefa arquivada</p>
          </div>
        ) : (
          historyTasks.map((task) => (
            <div key={task.id} className="group relative">
               <div className="opacity-70 grayscale">
                  <TaskCard task={task} />
               </div>
               <Button
                variant="destructive"
                size="icon"
                className="absolute right-2 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"
                onClick={() => deleteTask(task.id)}
               >
                 <Trash2 size={16} />
               </Button>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
