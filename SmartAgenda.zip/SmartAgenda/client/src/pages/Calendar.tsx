import { useState } from "react";
import { useStore } from "@/lib/store";
import { 
  ChevronLeft, 
  ChevronRight, 
  Clock, 
  Plus, 
  ArrowLeft,
  Calendar as CalendarIcon
} from "lucide-react";
import { 
  format, 
  addMonths, 
  subMonths, 
  startOfMonth, 
  endOfMonth, 
  eachDayOfInterval, 
  isSameMonth, 
  isSameDay, 
  isToday,
  getDay
} from "date-fns";
import { ptBR } from "date-fns/locale";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Link } from "wouter";
import { TaskCard } from "@/components/TaskCard";

export default function Calendar() {
  const { tasks } = useStore();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());

  // Calendar Logic
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(monthStart);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

  // Padding days for grid alignment
  const startDay = getDay(monthStart); // 0 = Sunday
  const paddingDays = Array.from({ length: startDay });

  // Navigation
  const prevMonth = () => setCurrentDate(subMonths(currentDate, 1));
  const nextMonth = () => setCurrentDate(addMonths(currentDate, 1));

  // Filter events for selected date
  const selectedDateTasks = tasks.filter(task => {
    if (task.archived) return false;
    // Convert task string date (YYYY-MM-DD) to Date object for comparison
    const taskDate = new Date(task.date + 'T00:00:00'); 
    return isSameDay(taskDate, selectedDate);
  });

  // Check if a date has events
  const hasEvents = (date: Date) => {
    return tasks.some(task => {
      if (task.archived) return false;
      const taskDate = new Date(task.date + 'T00:00:00');
      return isSameDay(taskDate, date);
    });
  };

  // Open Add Task Modal
  const openAddTask = () => {
    document.dispatchEvent(new CustomEvent('open-add-task'));
  };

  return (
    <div className="min-h-screen bg-background pb-24 px-4 pt-6 flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-center mb-6 relative">
        <div className="flex items-center gap-2 text-xl font-bold uppercase tracking-wider">
          <CalendarIcon className="text-primary" size={24} />
          <span>Agenda</span>
        </div>
      </div>

      {/* Calendar Card */}
      <div className="bg-card rounded-2xl shadow-lg p-4 mb-4 border border-border/50">
        {/* Month Navigation */}
        <div className="flex items-center justify-between mb-6 px-2">
          <button 
            onClick={prevMonth}
            className="text-primary hover:text-primary/80 transition-colors p-1"
          >
            <ChevronLeft size={24} />
          </button>
          
          <h2 className="text-base font-medium capitalize">
            {format(currentDate, "MMMM yyyy", { locale: ptBR })}
          </h2>
          
          <button 
            onClick={nextMonth}
            className="text-primary hover:text-primary/80 transition-colors p-1"
          >
            <ChevronRight size={24} />
          </button>
        </div>

        {/* Week Days Header */}
        <div className="grid grid-cols-7 gap-1 mb-2 text-center">
          {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map(day => (
            <div key={day} className="text-xs text-purple-300/70 font-medium py-2">
              {day}
            </div>
          ))}
        </div>

        {/* Days Grid */}
        <div className="grid grid-cols-7 gap-1">
          {/* Padding for start of month */}
          {paddingDays.map((_, i) => (
            <div key={`pad-${i}`} className="h-10" />
          ))}

          {/* Actual Days */}
          {daysInMonth.map((date) => {
            const isSelected = isSameDay(date, selectedDate);
            const isCurrentMonth = isSameMonth(date, currentDate);
            const isTodayDate = isToday(date);
            const hasEvent = hasEvents(date);

            return (
              <div key={date.toString()} className="flex justify-center">
                <button
                  onClick={() => setSelectedDate(date)}
                  className={cn(
                    "h-10 w-10 rounded-full flex items-center justify-center text-sm relative transition-all",
                    !isCurrentMonth && "opacity-30",
                    isSelected 
                      ? "bg-primary text-primary-foreground shadow-glow font-bold" 
                      : "hover:bg-white/5 text-foreground/90",
                    isTodayDate && !isSelected && "text-primary font-bold border border-primary/30"
                  )}
                >
                  {format(date, "d")}
                  
                  {/* Event Dot */}
                  {hasEvent && !isSelected && (
                    <div className="absolute bottom-1.5 w-1 h-1 bg-primary rounded-full" />
                  )}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Date Header */}
      <div className="bg-card rounded-xl p-4 mb-4 flex items-center justify-between shadow-md border border-border/50">
        <h3 className="font-bold text-lg capitalize">
          {format(selectedDate, "d 'de' MMMM", { locale: ptBR })}
        </h3>
        <Button 
          size="icon" 
          className="rounded-full h-10 w-10 bg-primary hover:bg-primary/90 shadow-glow"
          onClick={openAddTask}
        >
          <Plus className="text-white" />
        </Button>
      </div>

      {/* Events List */}
      <div className="flex-1 bg-card rounded-2xl p-4 shadow-inner-lg min-h-[200px] border border-border/50 relative overflow-hidden">
        {selectedDateTasks.length === 0 ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-muted-foreground/50">
            <Clock size={48} className="mb-4 opacity-20" />
            <p className="text-sm font-medium">Nenhum evento hoje</p>
          </div>
        ) : (
          <div className="space-y-3 relative z-10">
            <AnimatePresence mode="popLayout">
              {selectedDateTasks.map((task) => (
                <TaskCard key={task.id} task={task} />
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>
      
      <div className="mt-4 mb-2">
        <Link href="/">
           <Button className="w-full bg-primary hover:bg-primary/90 text-white rounded-xl h-12 font-medium">
             <ArrowLeft className="mr-2 h-4 w-4" /> Voltar
           </Button>
        </Link>
      </div>

    </div>
  );
}
