import { useStore } from "@/lib/store";
import { TaskCard } from "@/components/TaskCard";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { motion } from "framer-motion";
import { Bell, Search } from "lucide-react";
import generatedImage from '@assets/generated_images/user_profile_avatar.png';

export default function Home() {
  const { settings, tasks } = useStore();
  
  const today = format(new Date(), 'yyyy-MM-dd');
  const todaysTasks = tasks.filter(t => t.date === today && !t.archived);
  const completedToday = todaysTasks.filter(t => t.completed).length;
  const progress = todaysTasks.length > 0 ? Math.round((completedToday / todaysTasks.length) * 100) : 0;

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <header className="px-6 pt-8 pb-4 flex justify-between items-start">
        <div>
          <p className="text-muted-foreground text-sm font-medium">
            {format(new Date(), "EEEE, d 'de' MMMM", { locale: ptBR })}
          </p>
          <h1 className="text-2xl font-bold mt-1">
            Olá, {settings.username}
          </h1>
        </div>
        <div className="relative">
          <img 
            src={settings.avatarUrl || generatedImage} 
            alt="Profile" 
            className="w-10 h-10 rounded-full object-cover border-2 border-background shadow-sm"
          />
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full border-2 border-background" />
        </div>
      </header>

      {/* Widget Area */}
      <div className="px-6 mb-8">
        <div className="bg-primary text-primary-foreground rounded-2xl p-6 shadow-lg shadow-primary/20 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-10 -mt-10 blur-2xl" />
          
          <div className="relative z-10">
            <h2 className="text-lg font-semibold mb-1">Seu Progresso Diário</h2>
            <p className="text-primary-foreground/80 text-sm mb-4">
              Você completou {completedToday} de {todaysTasks.length} tarefas hoje
            </p>
            
            <div className="h-2 bg-black/20 rounded-full overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                className="h-full bg-white rounded-full"
                transition={{ duration: 1, ease: "easeOut" }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Tasks Section */}
      <div className="px-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold">Para Hoje</h2>
          <span className="text-xs font-medium bg-muted px-2 py-1 rounded-full text-muted-foreground">
            {todaysTasks.length}
          </span>
        </div>

        <div className="space-y-3">
          {todaysTasks.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground text-sm bg-muted/30 rounded-xl border border-dashed">
              <p>Nenhuma tarefa para hoje!</p>
              <p className="text-xs mt-1">Aproveite seu dia livre 🎉</p>
            </div>
          ) : (
            todaysTasks.map((task) => (
              <TaskCard key={task.id} task={task} />
            ))
          )}
        </div>
      </div>
    </div>
  );
}
