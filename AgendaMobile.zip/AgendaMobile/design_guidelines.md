# AgendaGO - Design Guidelines

## Architecture Decisions

### Authentication
**No Authentication Required**
- The app is a local-first personal agenda/task manager
- All data stored locally using AsyncStorage
- Include a **Settings/Profile screen** with:
  - User-customizable avatar (allow photo upload or camera capture)
  - Display name field (editable text input)
  - App preferences (theme, notifications, default task time)

### Navigation
**Tab Navigation (3 Tabs)**
- **Home** (left): Calendar view with daily tasks
- **Add Task** (center, floating action button): Create new task
- **Settings** (right): User profile and app configuration

Tab bar specifications:
- Position: Bottom of screen
- Height: 60px + safe area bottom inset
- Background: Transparent with blur effect in Light theme, solid dark background in Dark theme
- Active tab icon color: Primary Purple (#8B5CF6)
- Inactive tab icon color: Gray (#94A3B8)

### Screen Specifications

#### 1. Home Screen (Calendar & Tasks)
- **Purpose**: View calendar, select dates, and manage daily tasks
- **Header**: Transparent with app name "AgendaGO" centered
  - Right button: Search icon (opens search modal)
  - No left button
  - Height: Custom 80px including safe area
- **Layout**:
  - Calendar widget at top (month view, current week highlighted)
  - Selected date indicator below calendar
  - Scrollable task list for selected day
  - Each task card shows: title, time, category badge, priority indicator
- **Safe Area Insets**: 
  - Top: headerHeight + 16px
  - Bottom: tabBarHeight + 24px
- **Components**: 
  - Interactive month calendar grid
  - Task cards with swipe actions (complete, delete, edit)
  - Floating action button for quick add (bottom right, 72px from bottom)
  - Empty state illustration when no tasks

#### 2. Add/Edit Task Screen (Modal)
- **Purpose**: Create or modify tasks with all attributes
- **Presentation**: Full-screen modal with slide-up animation
- **Header**: Non-transparent background
  - Left button: "Cancel" text button
  - Title: "Nova Tarefa" or "Editar Tarefa"
  - Right button: "Salvar" (primary purple when form valid, gray when invalid)
- **Layout**: Scrollable form with sections
  - Task name input field
  - Date picker (calendar icon, opens date selector)
  - Time picker (clock icon, shows time selection modal)
  - Notification time picker (bell icon, offset from task time)
  - Category selector (horizontal scrollable chips with colors)
  - Priority selector (3 segmented buttons: Alta/Média/Baixa)
  - Recurrence selector (None/Daily/Weekly/Monthly dropdown)
  - Notes field (multiline text input, optional)
- **Safe Area Insets**:
  - Top: 16px (header is non-transparent)
  - Bottom: 24px + keyboard height when active
- **Form buttons**: In header (not below form)

#### 3. Settings Screen
- **Purpose**: Configure app preferences and user profile
- **Header**: Transparent
  - Title: "Configurações"
  - No action buttons
- **Layout**: Scrollable list with grouped sections
  - **Profile Section** (top card):
    - Centered avatar (80px circle, tappable to change)
    - Centered name field (tappable to edit)
  - **Notifications Section**:
    - Toggle: Enable/disable notifications
    - Option: Notification sound (opens sound picker)
    - Time picker: Default task time
  - **Theme Section**:
    - Segmented control: Claro / Escuro / Colorido
    - Preview chip showing current theme colors
  - **Backup Section**:
    - Button: Export data
    - Button: Import data
  - **About Section**:
    - App version
    - Developer info
- **Safe Area Insets**:
  - Top: headerHeight + 16px
  - Bottom: tabBarHeight + 24px

#### 4. Search Modal
- **Purpose**: Find tasks by name, category, or date
- **Presentation**: Modal overlay with semi-transparent dark background
- **Header**: Search bar with cancel button
- **Layout**: 
  - Search input at top (auto-focus on mount)
  - Filter chips below (Category, Date, Priority)
  - Scrollable results list (same card style as home)
- **Safe Area Insets**: Top: insets.top + 16px, Bottom: 24px

#### 5. History/Archive Screen (Modal)
- **Purpose**: View completed and archived tasks
- **Presentation**: Full-screen modal
- **Header**: Non-transparent
  - Left button: Close (X icon)
  - Title: "Histórico"
- **Layout**: Scrollable list grouped by month
- **Safe Area Insets**: Top: 16px, Bottom: 24px

## Design System

### Color Palette
**Primary Colors** (from original):
- Primary Purple: `#8B5CF6`
- Light Purple: `#A78BFA`
- Dark Navy: `#2D3250`
- Deep Dark: `#1E293B`

**Theme Variations**:

**Light Theme**:
- Background: `#FFFFFF`
- Surface: `#F8FAFC`
- Text Primary: `#1E293B`
- Text Secondary: `#64748B`
- Border: `#E2E8F0`

**Dark Theme**:
- Background: `#1E293B`
- Surface: `#2D3250`
- Text Primary: `#F8FAFC`
- Text Secondary: `#94A3B8`
- Border: `#334155`

**Colorful Theme** (enhanced vibrance):
- Same as Light but with 20% increased saturation on purple tones
- Gradient backgrounds for task cards
- Animated transitions

**Category Colors** (customizable):
- Work: `#EF4444` (Red)
- Study: `#3B82F6` (Blue)
- Home: `#10B981` (Green)
- Project: `#F59E0B` (Orange)
- Custom: User-defined hex colors

**Priority Colors**:
- High: `#DC2626` (Red, with pulsing animation)
- Medium: `#F59E0B` (Orange)
- Low: `#6B7280` (Gray)

### Typography
**Font Family**: System default (SF Pro for iOS, Roboto for Android)

**Text Styles**:
- **Heading 1**: 28px, Bold, -0.5px letter spacing
- **Heading 2**: 22px, SemiBold
- **Body**: 16px, Regular, 1.5 line height
- **Caption**: 14px, Regular, Secondary color
- **Button Text**: 16px, SemiBold, Uppercase for primary actions

### Component Specifications

**Task Card**:
- Background: Surface color with subtle shadow
- Padding: 16px
- Border radius: 12px
- Left border: 4px solid category color
- Press feedback: Scale down to 0.98, opacity 0.8
- Shadow (Light theme only):
  - shadowOffset: {width: 0, height: 1}
  - shadowOpacity: 0.05
  - shadowRadius: 3

**Floating Action Button** (Add Task):
- Size: 56px circle
- Background: Primary Purple gradient
- Icon: Plus, white, 24px
- Shadow:
  - shadowOffset: {width: 0, height: 2}
  - shadowOpacity: 0.10
  - shadowRadius: 2
- Press: Scale to 1.1 with haptic feedback

**Toggle Switch**:
- Track: Gray when off, Primary Purple when on
- Thumb: White with subtle shadow
- iOS style for iOS, Material style for Android

**Input Fields**:
- Height: 48px
- Border: 1px solid Border color
- Border radius: 8px
- Focus state: Border changes to Primary Purple, 2px width
- Background: Surface color

**Category Badge**:
- Height: 24px
- Padding: 6px 12px
- Border radius: 12px (pill shape)
- Background: Category color at 20% opacity
- Text: Category color at 100% opacity, 12px

**Calendar Widget**:
- Day cell: 40px circle
- Selected day: Primary Purple background, white text
- Today: Border with Primary Purple
- Has tasks: Small dot indicator below date (4px circle)
- Past dates: 50% opacity

### Visual Design
- **Icons**: Use Feather icon set from @expo/vector-icons
- **Spacing System**: 4px base (4, 8, 12, 16, 24, 32, 48)
- **Border Radius**: Small: 8px, Medium: 12px, Large: 16px
- **Animations**: 
  - Screen transitions: 300ms ease-in-out
  - Component interactions: 200ms
  - Notification badges: Pulse animation (1.5s loop)
- **Haptic Feedback**: On button press, task complete, swipe actions

### Interaction Design
- **Swipe Actions on Task Cards**:
  - Left swipe: Delete (red background, trash icon)
  - Right swipe: Complete (green background, check icon)
- **Long Press**: On task card opens edit modal
- **Pull to Refresh**: On Home screen calendar/task list
- **Keyboard Behavior**: Dismiss on scroll or tap outside
- **Loading States**: Skeleton screens for initial load, spinners for actions

### Accessibility Requirements
- Minimum touch target: 44x44px
- Color contrast ratio: 4.5:1 for text, 3:1 for UI components
- VoiceOver/TalkBack labels for all interactive elements
- Support for system font size scaling (up to 200%)
- Haptic feedback for important actions
- Alternative text for all icons

### Required Assets
**Generate these assets**:
1. **App Icon**: Circular calendar icon with "AG" monogram in Primary Purple gradient
2. **Empty State Illustration**: Simple line drawing of a calendar with checkmarks (matching color scheme)
3. **Default Avatar Options**: 6 preset avatars in geometric/minimalist style with purple accent colors
4. **Onboarding Screens** (3 slides):
   - Screen 1: Calendar illustration - "Organize suas tarefas"
   - Screen 2: Bell illustration - "Nunca esqueça nada"
   - Screen 3: Categories illustration - "Categorize e priorize"

All illustrations should use flat design with the defined color palette, no gradients except for primary CTAs.