import React from "react";
import { View, Text, StyleSheet, Pressable } from "react-native";
import { Feather } from "@expo/vector-icons";
import Animated, { FadeInDown } from "react-native-reanimated";
import { Task, Category } from "@/types";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius } from "@/constants/theme";

interface TaskCardProps {
  task: Task;
  category?: Category;
  onPress: () => void;
  onToggleComplete: () => void;
  onDelete: () => void;
  index: number;
}

export const TaskCard = ({
  task,
  category,
  onPress,
  onToggleComplete,
  onDelete,
  index,
}: TaskCardProps) => {
  const { theme } = useTheme();

  const getPriorityColor = () => {
    switch (task.priority) {
      case "high":
        return theme.priorityHigh;
      case "medium":
        return theme.priorityMedium;
      case "low":
        return theme.priorityLow;
      default:
        return theme.textSecondary;
    }
  };

  const getPriorityLabel = () => {
    switch (task.priority) {
      case "high":
        return "Alta";
      case "medium":
        return "Média";
      case "low":
        return "Baixa";
      default:
        return "";
    }
  };

  return (
    <Animated.View
      entering={FadeInDown.delay(index * 50)}
    >
      <Pressable
        style={({ pressed }) => [
          styles.container,
          { backgroundColor: theme.backgroundSecondary, borderLeftColor: category?.color || theme.primary },
          pressed && styles.pressed,
          task.completed && styles.completed,
        ]}
        onPress={onPress}
      >
        <View style={styles.content}>
          <View style={styles.header}>
            <View style={styles.titleRow}>
              <Pressable onPress={onToggleComplete} style={styles.checkbox}>
                <View
                  style={[
                    styles.checkboxInner,
                    { borderColor: theme.primary },
                    task.completed && { backgroundColor: theme.primary },
                  ]}
                >
                  {task.completed && (
                    <Feather name="check" size={16} color="#fff" />
                  )}
                </View>
              </Pressable>
              
              <Text
                style={[
                  styles.title,
                  { color: theme.text },
                  task.completed && styles.completedText,
                ]}
                numberOfLines={1}
              >
                {task.title}
              </Text>
            </View>

            <Pressable onPress={onDelete} style={styles.deleteButton}>
              <Feather name="trash-2" size={18} color={theme.textSecondary} />
            </Pressable>
          </View>

          <View style={styles.details}>
            <View style={styles.row}>
              <Feather name="clock" size={14} color={theme.textSecondary} />
              <Text style={[styles.detailText, { color: theme.textSecondary }]}>
                {task.time}
              </Text>
            </View>

            {category && (
              <View
                style={[
                  styles.categoryBadge,
                  { backgroundColor: `${category.color}33` },
                ]}
              >
                <Text style={[styles.categoryText, { color: category.color }]}>
                  {category.name}
                </Text>
              </View>
            )}

            <View
              style={[
                styles.priorityBadge,
                { backgroundColor: `${getPriorityColor()}33` },
              ]}
            >
              <Text style={[styles.priorityText, { color: getPriorityColor() }]}>
                {getPriorityLabel()}
              </Text>
            </View>
          </View>

          {task.recurrence !== "none" && (
            <View style={styles.recurrence}>
              <Feather name="repeat" size={14} color={theme.textSecondary} />
              <Text style={[styles.detailText, { color: theme.textSecondary }]}>
                {task.recurrence === "daily" && "Diário"}
                {task.recurrence === "weekly" && "Semanal"}
                {task.recurrence === "monthly" && "Mensal"}
              </Text>
            </View>
          )}
        </View>
      </Pressable>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    borderRadius: BorderRadius.sm,
    marginBottom: Spacing.md,
    borderLeftWidth: 4,
    overflow: "hidden",
  },
  pressed: {
    opacity: 0.8,
  },
  completed: {
    opacity: 0.6,
  },
  content: {
    padding: Spacing.lg,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: Spacing.sm,
  },
  titleRow: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.md,
  },
  checkbox: {
    padding: Spacing.xs,
  },
  checkboxInner: {
    width: 24,
    height: 24,
    borderRadius: 6,
    borderWidth: 2,
    justifyContent: "center",
    alignItems: "center",
  },
  title: {
    flex: 1,
    fontSize: 16,
    fontWeight: "600",
  },
  completedText: {
    textDecorationLine: "line-through",
  },
  deleteButton: {
    padding: Spacing.xs,
  },
  details: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.md,
    flexWrap: "wrap",
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.xs,
  },
  detailText: {
    fontSize: 14,
  },
  categoryBadge: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.xs,
  },
  categoryText: {
    fontSize: 12,
    fontWeight: "600",
  },
  priorityBadge: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.xs,
  },
  priorityText: {
    fontSize: 12,
    fontWeight: "600",
  },
  recurrence: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.xs,
    marginTop: Spacing.sm,
  },
});
