export type Priority = "high" | "medium" | "low";
export type Recurrence = "none" | "daily" | "weekly" | "monthly";
export type ThemeMode = "light" | "dark" | "colorful";

export interface Category {
  id: string;
  name: string;
  color: string;
}

export interface Task {
  id: string;
  title: string;
  date: string;
  time: string;
  notificationTime?: string;
  category: string;
  priority: Priority;
  recurrence: Recurrence;
  notes?: string;
  completed: boolean;
  archived: boolean;
  createdAt: string;
}

export interface UserSettings {
  name: string;
  avatar?: string;
  notificationsEnabled: boolean;
  notificationSound: string;
  defaultTaskTime: string;
  theme: ThemeMode;
}

export const DEFAULT_CATEGORIES: Category[] = [
  { id: "work", name: "Trabalho", color: "#EF4444" },
  { id: "study", name: "Estudos", color: "#3B82F6" },
  { id: "home", name: "Casa", color: "#10B981" },
  { id: "project", name: "Projeto", color: "#F59E0B" },
];

export const DEFAULT_SETTINGS: UserSettings = {
  name: "Usuário",
  notificationsEnabled: true,
  notificationSound: "default",
  defaultTaskTime: "09:00",
  theme: "light",
};
