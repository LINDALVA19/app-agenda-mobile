import AsyncStorage from "@react-native-async-storage/async-storage";
import { Task, Category, UserSettings, DEFAULT_CATEGORIES, DEFAULT_SETTINGS } from "@/types";

const KEYS = {
  TASKS: "@agendago:tasks",
  CATEGORIES: "@agendago:categories",
  SETTINGS: "@agendago:settings",
  FIRST_LAUNCH: "@agendago:first_launch",
};

export const storage = {
  async getTasks(): Promise<Task[]> {
    try {
      const data = await AsyncStorage.getItem(KEYS.TASKS);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error("Error getting tasks:", error);
      return [];
    }
  },

  async saveTasks(tasks: Task[]): Promise<void> {
    try {
      await AsyncStorage.setItem(KEYS.TASKS, JSON.stringify(tasks));
    } catch (error) {
      console.error("Error saving tasks:", error);
    }
  },

  async getCategories(): Promise<Category[]> {
    try {
      const data = await AsyncStorage.getItem(KEYS.CATEGORIES);
      return data ? JSON.parse(data) : DEFAULT_CATEGORIES;
    } catch (error) {
      console.error("Error getting categories:", error);
      return DEFAULT_CATEGORIES;
    }
  },

  async saveCategories(categories: Category[]): Promise<void> {
    try {
      await AsyncStorage.setItem(KEYS.CATEGORIES, JSON.stringify(categories));
    } catch (error) {
      console.error("Error saving categories:", error);
    }
  },

  async getSettings(): Promise<UserSettings> {
    try {
      const data = await AsyncStorage.getItem(KEYS.SETTINGS);
      return data ? JSON.parse(data) : DEFAULT_SETTINGS;
    } catch (error) {
      console.error("Error getting settings:", error);
      return DEFAULT_SETTINGS;
    }
  },

  async saveSettings(settings: UserSettings): Promise<void> {
    try {
      await AsyncStorage.setItem(KEYS.SETTINGS, JSON.stringify(settings));
    } catch (error) {
      console.error("Error saving settings:", error);
    }
  },

  async isFirstLaunch(): Promise<boolean> {
    try {
      const value = await AsyncStorage.getItem(KEYS.FIRST_LAUNCH);
      if (value === null) {
        await AsyncStorage.setItem(KEYS.FIRST_LAUNCH, "false");
        return true;
      }
      return false;
    } catch (error) {
      console.error("Error checking first launch:", error);
      return false;
    }
  },
};
