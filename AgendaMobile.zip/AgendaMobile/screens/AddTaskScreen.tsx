import React, { useState, useEffect } from "react";
import {
  StyleSheet,
  TextInput,
  Pressable,
  View,
  Platform,
  ScrollView,
  Alert,
} from "react-native";
import { useNavigation, useRoute } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { Feather } from "@expo/vector-icons";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { ScreenKeyboardAwareScrollView } from "@/components/ScreenKeyboardAwareScrollView";
import { useTheme } from "@/hooks/useTheme";
import { useApp } from "@/contexts/AppContext";
import { Spacing, BorderRadius } from "@/constants/theme";
import { Priority, Recurrence } from "@/types";

type AddTaskScreenProp = NativeStackNavigationProp<any>;

export default function AddTaskScreen() {
  const navigation = useNavigation<AddTaskScreenProp>();
  const route = useRoute();
  const { theme } = useTheme();
  const { tasks, categories, addTask, updateTask } = useApp();
  
  const taskId = (route.params as any)?.taskId;
  const editingTask = taskId ? tasks.find((t) => t.id === taskId) : null;

  const [title, setTitle] = useState(editingTask?.title || "");
  const [date, setDate] = useState(editingTask ? new Date(editingTask.date) : new Date());
  const [time, setTime] = useState(editingTask?.time || "09:00");
  const [notificationTime, setNotificationTime] = useState(editingTask?.notificationTime || "09:00");
  const [category, setCategory] = useState(editingTask?.category || categories[0]?.id || "");
  const [priority, setPriority] = useState<Priority>(editingTask?.priority || "medium");
  const [recurrence, setRecurrence] = useState<Recurrence>(editingTask?.recurrence || "none");
  const [notes, setNotes] = useState(editingTask?.notes || "");

  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [showNotificationPicker, setShowNotificationPicker] = useState(false);

  React.useLayoutEffect(() => {
    navigation.setOptions({
      headerTitle: editingTask ? "Editar Tarefa" : "Nova Tarefa",
      headerLeft: () => (
        <Pressable onPress={() => navigation.goBack()} style={styles.headerButton}>
          <ThemedText style={{ color: theme.text }}>Cancelar</ThemedText>
        </Pressable>
      ),
      headerRight: () => (
        <Pressable
          onPress={handleSave}
          style={styles.headerButton}
          disabled={!title.trim()}
        >
          <ThemedText
            style={{
              color: title.trim() ? theme.primary : theme.textSecondary,
              fontWeight: "600",
            }}
          >
            Salvar
          </ThemedText>
        </Pressable>
      ),
    });
  }, [navigation, theme, title, editingTask]);

  const handleSave = async () => {
    if (!title.trim()) return;

    const taskData = {
      title: title.trim(),
      date: date.toISOString().split("T")[0],
      time,
      notificationTime,
      category,
      priority,
      recurrence,
      notes: notes.trim(),
    };

    if (editingTask) {
      await updateTask(editingTask.id, taskData);
    } else {
      await addTask(taskData);
    }

    navigation.goBack();
  };

  const handleDatePicker = () => {
    Alert.alert("Selecionar Data", "Seletor de data será implementado em breve.");
  };

  const handleTimePicker = () => {
    Alert.alert("Selecionar Horário", "Seletor de horário será implementado em breve.");
  };

  const handleNotificationPicker = () => {
    Alert.alert("Horário de Notificação", "Seletor de notificação será implementado em breve.");
  };

  const formatDate = () => {
    const day = date.getDate();
    const month = date.getMonth() + 1;
    const year = date.getFullYear();
    return `${day.toString().padStart(2, "0")}/${month.toString().padStart(2, "0")}/${year}`;
  };

  return (
    <ScreenKeyboardAwareScrollView style={styles.container}>
      <View style={styles.section}>
        <ThemedText style={styles.label}>Título da Tarefa</ThemedText>
        <TextInput
          style={[
            styles.input,
            {
              backgroundColor: theme.backgroundSecondary,
              color: theme.text,
              borderColor: theme.border,
            },
          ]}
          value={title}
          onChangeText={setTitle}
          placeholder="Digite o título"
          placeholderTextColor={theme.textSecondary}
        />
      </View>

      <View style={styles.section}>
        <ThemedText style={styles.label}>Data</ThemedText>
        <Pressable
          style={[
            styles.picker,
            { backgroundColor: theme.backgroundSecondary, borderColor: theme.border },
          ]}
          onPress={handleDatePicker}
        >
          <Feather name="calendar" size={20} color={theme.textSecondary} />
          <ThemedText>{formatDate()}</ThemedText>
        </Pressable>
      </View>

      <View style={styles.section}>
        <ThemedText style={styles.label}>Horário</ThemedText>
        <Pressable
          style={[
            styles.picker,
            { backgroundColor: theme.backgroundSecondary, borderColor: theme.border },
          ]}
          onPress={handleTimePicker}
        >
          <Feather name="clock" size={20} color={theme.textSecondary} />
          <ThemedText>{time}</ThemedText>
        </Pressable>
      </View>

      <View style={styles.section}>
        <ThemedText style={styles.label}>Notificação</ThemedText>
        <Pressable
          style={[
            styles.picker,
            { backgroundColor: theme.backgroundSecondary, borderColor: theme.border },
          ]}
          onPress={handleNotificationPicker}
        >
          <Feather name="bell" size={20} color={theme.textSecondary} />
          <ThemedText>{notificationTime}</ThemedText>
        </Pressable>
      </View>

      <View style={styles.section}>
        <ThemedText style={styles.label}>Categoria</ThemedText>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.horizontalScroll}>
          {categories.map((cat) => (
            <Pressable
              key={cat.id}
              style={[
                styles.categoryChip,
                {
                  backgroundColor:
                    category === cat.id ? cat.color : `${cat.color}33`,
                  borderColor: cat.color,
                  borderWidth: category === cat.id ? 2 : 0,
                },
              ]}
              onPress={() => setCategory(cat.id)}
            >
              <ThemedText
                style={[
                  styles.categoryText,
                  { color: category === cat.id ? "#fff" : cat.color },
                ]}
              >
                {cat.name}
              </ThemedText>
            </Pressable>
          ))}
        </ScrollView>
      </View>

      <View style={styles.section}>
        <ThemedText style={styles.label}>Prioridade</ThemedText>
        <View style={styles.row}>
          {[
            { value: "high" as Priority, label: "Alta", color: theme.priorityHigh },
            { value: "medium" as Priority, label: "Média", color: theme.priorityMedium },
            { value: "low" as Priority, label: "Baixa", color: theme.priorityLow },
          ].map((p) => (
            <Pressable
              key={p.value}
              style={[
                styles.priorityButton,
                {
                  backgroundColor: priority === p.value ? p.color : `${p.color}33`,
                  borderColor: p.color,
                  borderWidth: priority === p.value ? 2 : 0,
                },
              ]}
              onPress={() => setPriority(p.value)}
            >
              <ThemedText
                style={[
                  styles.priorityText,
                  { color: priority === p.value ? "#fff" : p.color },
                ]}
              >
                {p.label}
              </ThemedText>
            </Pressable>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <ThemedText style={styles.label}>Recorrência</ThemedText>
        <View style={styles.row}>
          {[
            { value: "none" as Recurrence, label: "Nenhuma" },
            { value: "daily" as Recurrence, label: "Diário" },
            { value: "weekly" as Recurrence, label: "Semanal" },
            { value: "monthly" as Recurrence, label: "Mensal" },
          ].map((r) => (
            <Pressable
              key={r.value}
              style={[
                styles.recurrenceButton,
                {
                  backgroundColor:
                    recurrence === r.value ? theme.primary : theme.backgroundSecondary,
                  borderColor: theme.primary,
                  borderWidth: recurrence === r.value ? 2 : 1,
                },
              ]}
              onPress={() => setRecurrence(r.value)}
            >
              <ThemedText
                style={[
                  styles.recurrenceText,
                  { color: recurrence === r.value ? "#fff" : theme.text },
                ]}
              >
                {r.label}
              </ThemedText>
            </Pressable>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <ThemedText style={styles.label}>Notas (opcional)</ThemedText>
        <TextInput
          style={[
            styles.input,
            styles.notesInput,
            {
              backgroundColor: theme.backgroundSecondary,
              color: theme.text,
              borderColor: theme.border,
            },
          ]}
          value={notes}
          onChangeText={setNotes}
          placeholder="Adicione notas"
          placeholderTextColor={theme.textSecondary}
          multiline
          numberOfLines={4}
          textAlignVertical="top"
        />
      </View>
    </ScreenKeyboardAwareScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  headerButton: {
    padding: Spacing.md,
  },
  section: {
    marginBottom: Spacing["2xl"],
  },
  label: {
    fontSize: 16,
    fontWeight: "600",
    marginBottom: Spacing.sm,
  },
  input: {
    height: 48,
    borderWidth: 1,
    borderRadius: BorderRadius.xs,
    paddingHorizontal: Spacing.lg,
    fontSize: 16,
  },
  notesInput: {
    height: 100,
    paddingTop: Spacing.md,
  },
  picker: {
    flexDirection: "row",
    alignItems: "center",
    height: 48,
    borderWidth: 1,
    borderRadius: BorderRadius.xs,
    paddingHorizontal: Spacing.lg,
    gap: Spacing.md,
  },
  horizontalScroll: {
    flexDirection: "row",
  },
  categoryChip: {
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.xs,
    marginRight: Spacing.sm,
  },
  categoryText: {
    fontSize: 14,
    fontWeight: "600",
  },
  row: {
    flexDirection: "row",
    gap: Spacing.sm,
    flexWrap: "wrap",
  },
  priorityButton: {
    flex: 1,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.xs,
    alignItems: "center",
  },
  priorityText: {
    fontSize: 14,
    fontWeight: "600",
  },
  recurrenceButton: {
    flex: 1,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.xs,
    alignItems: "center",
    minWidth: 70,
  },
  recurrenceText: {
    fontSize: 12,
    fontWeight: "600",
  },
});
