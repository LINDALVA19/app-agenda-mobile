import React, { useState } from "react";
import {
  StyleSheet,
  View,
  Pressable,
  TextInput,
  Switch,
  Alert,
  Image,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { ThemedText } from "@/components/ThemedText";
import { ScreenScrollView } from "@/components/ScreenScrollView";
import { useTheme } from "@/hooks/useTheme";
import { useApp } from "@/contexts/AppContext";
import { useColorScheme } from "@/hooks/useColorScheme";
import { Spacing, BorderRadius } from "@/constants/theme";
import { ThemeMode } from "@/types";

export default function SettingsScreen() {
  const { theme } = useTheme();
  const colorScheme = useColorScheme();
  const { settings, updateSettings } = useApp();
  
  const [editingName, setEditingName] = useState(false);
  const [tempName, setTempName] = useState(settings.name);

  const handlePickImage = async () => {
    Alert.alert(
      "Em breve",
      "Funcionalidade de seleção de foto será adicionada em breve."
    );
  };

  const handleSaveName = async () => {
    if (tempName.trim()) {
      await updateSettings({ name: tempName.trim() });
      setEditingName(false);
    }
  };

  const handleThemeChange = async (themeMode: ThemeMode) => {
    await updateSettings({ theme: themeMode });
  };

  return (
    <ScreenScrollView style={styles.container}>
      <View style={[styles.profileSection, { backgroundColor: theme.backgroundSecondary }]}>
        <Pressable onPress={handlePickImage} style={styles.avatarContainer}>
          {settings.avatar ? (
            <Image source={{ uri: settings.avatar }} style={styles.avatar} />
          ) : (
            <View style={[styles.avatarPlaceholder, { backgroundColor: theme.primary }]}>
              <Feather name="user" size={40} color="#fff" />
            </View>
          )}
          <View style={[styles.avatarBadge, { backgroundColor: theme.primary }]}>
            <Feather name="camera" size={16} color="#fff" />
          </View>
        </Pressable>

        {editingName ? (
          <View style={styles.nameEditContainer}>
            <TextInput
              style={[
                styles.nameInput,
                {
                  backgroundColor: theme.backgroundRoot,
                  color: theme.text,
                  borderColor: theme.border,
                },
              ]}
              value={tempName}
              onChangeText={setTempName}
              onSubmitEditing={handleSaveName}
              autoFocus
            />
            <Pressable onPress={handleSaveName}>
              <Feather name="check" size={24} color={theme.primary} />
            </Pressable>
          </View>
        ) : (
          <Pressable
            onPress={() => setEditingName(true)}
            style={styles.nameContainer}
          >
            <ThemedText style={styles.name}>{settings.name}</ThemedText>
            <Feather name="edit-2" size={16} color={theme.textSecondary} />
          </Pressable>
        )}
      </View>

      <View style={styles.section}>
        <ThemedText style={styles.sectionTitle}>Notificações</ThemedText>
        
        <View style={[styles.settingRow, { backgroundColor: theme.backgroundSecondary }]}>
          <View style={styles.settingInfo}>
            <Feather name="bell" size={20} color={theme.text} />
            <ThemedText style={styles.settingLabel}>Ativar notificações</ThemedText>
          </View>
          <Switch
            value={settings.notificationsEnabled}
            onValueChange={(value) => updateSettings({ notificationsEnabled: value })}
            trackColor={{ false: theme.textSecondary, true: theme.primary }}
            thumbColor="#fff"
          />
        </View>

        <View style={[styles.settingRow, { backgroundColor: theme.backgroundSecondary }]}>
          <View style={styles.settingInfo}>
            <Feather name="volume-2" size={20} color={theme.text} />
            <ThemedText style={styles.settingLabel}>Som de notificação</ThemedText>
          </View>
          <ThemedText style={[styles.settingValue, { color: theme.textSecondary }]}>
            {settings.notificationSound}
          </ThemedText>
        </View>

        <View style={[styles.settingRow, { backgroundColor: theme.backgroundSecondary }]}>
          <View style={styles.settingInfo}>
            <Feather name="clock" size={20} color={theme.text} />
            <ThemedText style={styles.settingLabel}>Horário padrão das tarefas</ThemedText>
          </View>
          <ThemedText style={[styles.settingValue, { color: theme.textSecondary }]}>
            {settings.defaultTaskTime}
          </ThemedText>
        </View>
      </View>

      <View style={styles.section}>
        <ThemedText style={styles.sectionTitle}>Tema</ThemedText>
        
        <View style={styles.themeOptions}>
          {[
            { value: "light" as ThemeMode, label: "Claro", icon: "sun" },
            { value: "dark" as ThemeMode, label: "Escuro", icon: "moon" },
            { value: "colorful" as ThemeMode, label: "Colorido", icon: "droplet" },
          ].map((option) => (
            <Pressable
              key={option.value}
              style={[
                styles.themeButton,
                {
                  backgroundColor:
                    settings.theme === option.value
                      ? theme.primary
                      : theme.backgroundSecondary,
                  borderColor: theme.primary,
                  borderWidth: settings.theme === option.value ? 2 : 0,
                },
              ]}
              onPress={() => handleThemeChange(option.value)}
            >
              <Feather
                name={option.icon as any}
                size={24}
                color={settings.theme === option.value ? "#fff" : theme.text}
              />
              <ThemedText
                style={[
                  styles.themeLabel,
                  { color: settings.theme === option.value ? "#fff" : theme.text },
                ]}
              >
                {option.label}
              </ThemedText>
            </Pressable>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <ThemedText style={styles.sectionTitle}>Backup</ThemedText>
        
        <Pressable
          style={[styles.settingRow, { backgroundColor: theme.backgroundSecondary }]}
          onPress={() => Alert.alert("Em breve", "Funcionalidade de backup será adicionada em breve.")}
        >
          <View style={styles.settingInfo}>
            <Feather name="upload" size={20} color={theme.text} />
            <ThemedText style={styles.settingLabel}>Exportar dados</ThemedText>
          </View>
          <Feather name="chevron-right" size={20} color={theme.textSecondary} />
        </Pressable>

        <Pressable
          style={[styles.settingRow, { backgroundColor: theme.backgroundSecondary }]}
          onPress={() => Alert.alert("Em breve", "Funcionalidade de importação será adicionada em breve.")}
        >
          <View style={styles.settingInfo}>
            <Feather name="download" size={20} color={theme.text} />
            <ThemedText style={styles.settingLabel}>Importar dados</ThemedText>
          </View>
          <Feather name="chevron-right" size={20} color={theme.textSecondary} />
        </Pressable>
      </View>

      <View style={styles.section}>
        <ThemedText style={styles.sectionTitle}>Sobre</ThemedText>
        
        <View style={[styles.settingRow, { backgroundColor: theme.backgroundSecondary }]}>
          <ThemedText style={styles.settingLabel}>Versão do aplicativo</ThemedText>
          <ThemedText style={[styles.settingValue, { color: theme.textSecondary }]}>
            2.0.0
          </ThemedText>
        </View>
      </View>
    </ScreenScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  profileSection: {
    alignItems: "center",
    padding: Spacing["2xl"],
    borderRadius: BorderRadius.sm,
    marginBottom: Spacing["2xl"],
  },
  avatarContainer: {
    position: "relative",
    marginBottom: Spacing.lg,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
  },
  avatarPlaceholder: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: "center",
    alignItems: "center",
  },
  avatarBadge: {
    position: "absolute",
    bottom: 0,
    right: 0,
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: "center",
    alignItems: "center",
  },
  nameContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
  },
  name: {
    fontSize: 20,
    fontWeight: "600",
  },
  nameEditContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.md,
    width: "100%",
  },
  nameInput: {
    flex: 1,
    height: 40,
    borderWidth: 1,
    borderRadius: BorderRadius.xs,
    paddingHorizontal: Spacing.md,
    fontSize: 16,
    textAlign: "center",
  },
  section: {
    marginBottom: Spacing["2xl"],
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "600",
    marginBottom: Spacing.md,
  },
  settingRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: Spacing.lg,
    borderRadius: BorderRadius.xs,
    marginBottom: Spacing.sm,
  },
  settingInfo: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.md,
    flex: 1,
  },
  settingLabel: {
    fontSize: 16,
  },
  settingValue: {
    fontSize: 14,
  },
  themeOptions: {
    flexDirection: "row",
    gap: Spacing.md,
  },
  themeButton: {
    flex: 1,
    alignItems: "center",
    padding: Spacing.lg,
    borderRadius: BorderRadius.xs,
    gap: Spacing.sm,
  },
  themeLabel: {
    fontSize: 14,
    fontWeight: "600",
  },
});
