import React, { useState, useMemo } from "react";
import { StyleSheet, TextInput, View, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Feather } from "@expo/vector-icons";
import { ThemedText } from "@/components/ThemedText";
import { ScreenScrollView } from "@/components/ScreenScrollView";
import { TaskCard } from "@/components/TaskCard";
import { useTheme } from "@/hooks/useTheme";
import { useApp } from "@/contexts/AppContext";
import { Spacing, BorderRadius } from "@/constants/theme";

export default function SearchScreen() {
  const navigation = useNavigation();
  const { theme } = useTheme();
  const { tasks, categories, toggleTaskComplete, deleteTask } = useApp();
  const [searchQuery, setSearchQuery] = useState("");
  const [filterCategory, setFilterCategory] = useState<string | null>(null);

  const filteredTasks = useMemo(() => {
    return tasks
      .filter((task) => {
        if (task.archived) return false;
        
        const matchesSearch =
          task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          task.notes?.toLowerCase().includes(searchQuery.toLowerCase());
        
        const matchesCategory =
          !filterCategory || task.category === filterCategory;
        
        return matchesSearch && matchesCategory;
      })
      .sort((a, b) => {
        const dateCompare = b.date.localeCompare(a.date);
        if (dateCompare !== 0) return dateCompare;
        return b.time.localeCompare(a.time);
      });
  }, [tasks, searchQuery, filterCategory]);

  React.useLayoutEffect(() => {
    navigation.setOptions({
      headerLeft: () => (
        <Pressable onPress={() => navigation.goBack()} style={styles.headerButton}>
          <Feather name="x" size={24} color={theme.text} />
        </Pressable>
      ),
    });
  }, [navigation, theme]);

  const handleTaskPress = (taskId: string) => {
    (navigation as any).navigate("AddTask", { taskId });
  };

  return (
    <ScreenScrollView style={styles.container}>
      <View style={styles.searchContainer}>
        <View style={[styles.searchBar, { backgroundColor: theme.backgroundSecondary, borderColor: theme.border }]}>
          <Feather name="search" size={20} color={theme.textSecondary} />
          <TextInput
            style={[styles.searchInput, { color: theme.text }]}
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholder="Buscar tarefas..."
            placeholderTextColor={theme.textSecondary}
            autoFocus
          />
          {searchQuery.length > 0 && (
            <Pressable onPress={() => setSearchQuery("")}>
              <Feather name="x-circle" size={20} color={theme.textSecondary} />
            </Pressable>
          )}
        </View>

        <View style={styles.filters}>
          <Pressable
            style={[
              styles.filterChip,
              {
                backgroundColor: !filterCategory ? theme.primary : theme.backgroundSecondary,
                borderColor: theme.primary,
              },
            ]}
            onPress={() => setFilterCategory(null)}
          >
            <ThemedText
              style={[
                styles.filterText,
                { color: !filterCategory ? "#fff" : theme.text },
              ]}
            >
              Todas
            </ThemedText>
          </Pressable>
          
          {categories.map((cat) => (
            <Pressable
              key={cat.id}
              style={[
                styles.filterChip,
                {
                  backgroundColor:
                    filterCategory === cat.id ? cat.color : theme.backgroundSecondary,
                  borderColor: cat.color,
                },
              ]}
              onPress={() => setFilterCategory(cat.id)}
            >
              <ThemedText
                style={[
                  styles.filterText,
                  { color: filterCategory === cat.id ? "#fff" : cat.color },
                ]}
              >
                {cat.name}
              </ThemedText>
            </Pressable>
          ))}
        </View>
      </View>

      <View style={styles.results}>
        <ThemedText style={[styles.resultCount, { color: theme.textSecondary }]}>
          {filteredTasks.length} {filteredTasks.length === 1 ? "tarefa encontrada" : "tarefas encontradas"}
        </ThemedText>

        {filteredTasks.map((task, index) => {
          const category = categories.find((cat) => cat.id === task.category);
          return (
            <TaskCard
              key={task.id}
              task={task}
              category={category}
              onPress={() => handleTaskPress(task.id)}
              onToggleComplete={() => toggleTaskComplete(task.id)}
              onDelete={() => deleteTask(task.id)}
              index={index}
            />
          );
        })}
      </View>
    </ScreenScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  headerButton: {
    padding: Spacing.md,
  },
  searchContainer: {
    marginBottom: Spacing.lg,
  },
  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    height: 48,
    borderWidth: 1,
    borderRadius: BorderRadius.xs,
    paddingHorizontal: Spacing.lg,
    gap: Spacing.md,
    marginBottom: Spacing.lg,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
  },
  filters: {
    flexDirection: "row",
    gap: Spacing.sm,
    flexWrap: "wrap",
  },
  filterChip: {
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.xs,
    borderWidth: 1,
  },
  filterText: {
    fontSize: 14,
    fontWeight: "600",
  },
  results: {
    flex: 1,
  },
  resultCount: {
    fontSize: 14,
    marginBottom: Spacing.lg,
  },
});
