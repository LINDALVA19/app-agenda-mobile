import React, { useMemo } from "react";
import { StyleSheet, View, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Feather } from "@expo/vector-icons";
import { ThemedText } from "@/components/ThemedText";
import { ScreenScrollView } from "@/components/ScreenScrollView";
import { TaskCard } from "@/components/TaskCard";
import { useTheme } from "@/hooks/useTheme";
import { useApp } from "@/contexts/AppContext";
import { Spacing, BorderRadius } from "@/constants/theme";

export default function HistoryScreen() {
  const navigation = useNavigation();
  const { theme } = useTheme();
  const { tasks, categories, deleteTask } = useApp();

  const archivedTasks = useMemo(() => {
    return tasks
      .filter((task) => task.archived || task.completed)
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [tasks]);

  const groupedByMonth = useMemo(() => {
    const groups: { [key: string]: typeof archivedTasks } = {};
    
    archivedTasks.forEach((task) => {
      const date = new Date(task.date);
      const monthYear = `${date.getMonth()}-${date.getFullYear()}`;
      
      if (!groups[monthYear]) {
        groups[monthYear] = [];
      }
      groups[monthYear].push(task);
    });
    
    return groups;
  }, [archivedTasks]);

  React.useLayoutEffect(() => {
    navigation.setOptions({
      headerLeft: () => (
        <Pressable onPress={() => navigation.goBack()} style={styles.headerButton}>
          <Feather name="x" size={24} color={theme.text} />
        </Pressable>
      ),
    });
  }, [navigation, theme]);

  const getMonthYearLabel = (monthYear: string) => {
    const [month, year] = monthYear.split("-");
    const months = [
      "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
      "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
    ];
    return `${months[parseInt(month)]} ${year}`;
  };

  return (
    <ScreenScrollView style={styles.container}>
      {archivedTasks.length === 0 ? (
        <View style={[styles.emptyState, { backgroundColor: theme.backgroundSecondary }]}>
          <Feather name="archive" size={48} color={theme.textSecondary} />
          <ThemedText style={[styles.emptyText, { color: theme.textSecondary }]}>
            Nenhuma tarefa arquivada
          </ThemedText>
        </View>
      ) : (
        Object.keys(groupedByMonth)
          .sort((a, b) => {
            const [monthA, yearA] = a.split("-").map(Number);
            const [monthB, yearB] = b.split("-").map(Number);
            if (yearB !== yearA) return yearB - yearA;
            return monthB - monthA;
          })
          .map((monthYear) => (
            <View key={monthYear} style={styles.monthGroup}>
              <ThemedText style={styles.monthTitle}>
                {getMonthYearLabel(monthYear)}
              </ThemedText>
              
              {groupedByMonth[monthYear].map((task, index) => {
                const category = categories.find((cat) => cat.id === task.category);
                return (
                  <TaskCard
                    key={task.id}
                    task={task}
                    category={category}
                    onPress={() => {}}
                    onToggleComplete={() => {}}
                    onDelete={() => deleteTask(task.id)}
                    index={index}
                  />
                );
              })}
            </View>
          ))
      )}
    </ScreenScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  headerButton: {
    padding: Spacing.md,
  },
  emptyState: {
    padding: Spacing["4xl"],
    borderRadius: BorderRadius.sm,
    alignItems: "center",
    justifyContent: "center",
    gap: Spacing.lg,
    marginTop: Spacing["2xl"],
  },
  emptyText: {
    fontSize: 16,
  },
  monthGroup: {
    marginBottom: Spacing["2xl"],
  },
  monthTitle: {
    fontSize: 18,
    fontWeight: "600",
    marginBottom: Spacing.lg,
  },
});
