import React, { useState, useMemo } from "react";
import { StyleSheet, Pressable, View, FlatList } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { Feather } from "@expo/vector-icons";
import { ThemedText } from "@/components/ThemedText";
import { ScreenScrollView } from "@/components/ScreenScrollView";
import { CalendarWidget } from "@/components/CalendarWidget";
import { TaskCard } from "@/components/TaskCard";
import { useTheme } from "@/hooks/useTheme";
import { useApp } from "@/contexts/AppContext";
import { Spacing, BorderRadius } from "@/constants/theme";

type CalendarScreenProp = NativeStackNavigationProp<any>;

export default function CalendarScreen() {
  const navigation = useNavigation<CalendarScreenProp>();
  const { theme } = useTheme();
  const { tasks, categories, toggleTaskComplete, deleteTask } = useApp();
  const [selectedDate, setSelectedDate] = useState(new Date());

  const taskDates = useMemo(() => {
    const dates = new Set<string>();
    tasks.forEach((task) => {
      if (!task.archived) {
        dates.add(task.date);
      }
    });
    return dates;
  }, [tasks]);

  const tasksForSelectedDate = useMemo(() => {
    const dateStr = selectedDate.toISOString().split("T")[0];
    return tasks
      .filter((task) => task.date === dateStr && !task.archived)
      .sort((a, b) => {
        const priorityOrder = { high: 0, medium: 1, low: 2 };
        const priorityDiff = priorityOrder[a.priority] - priorityOrder[b.priority];
        if (priorityDiff !== 0) return priorityDiff;
        return a.time.localeCompare(b.time);
      });
  }, [tasks, selectedDate]);

  const handleAddTask = () => {
    navigation.navigate("AddTask");
  };

  const handleTaskPress = (taskId: string) => {
    navigation.navigate("AddTask", { taskId });
  };

  const handleToggleComplete = async (taskId: string) => {
    await toggleTaskComplete(taskId);
  };

  const handleDeleteTask = async (taskId: string) => {
    await deleteTask(taskId);
  };

  const handleSearch = () => {
    navigation.navigate("Search");
  };

  React.useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <Pressable onPress={handleSearch} style={styles.headerButton}>
          <Feather name="search" size={24} color={theme.text} />
        </Pressable>
      ),
    });
  }, [navigation, theme]);

  const formatSelectedDate = () => {
    const day = selectedDate.getDate();
    const months = [
      "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
      "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
    ];
    return `${day} de ${months[selectedDate.getMonth()]}`;
  };

  return (
    <ScreenScrollView style={styles.container}>
      <CalendarWidget
        selectedDate={selectedDate}
        onDateSelect={setSelectedDate}
        taskDates={taskDates}
      />

      <View style={styles.taskSection}>
        <ThemedText style={styles.dateTitle}>{formatSelectedDate()}</ThemedText>

        {tasksForSelectedDate.length === 0 ? (
          <View style={[styles.emptyState, { backgroundColor: theme.backgroundSecondary }]}>
            <Feather name="clipboard" size={48} color={theme.textSecondary} />
            <ThemedText style={[styles.emptyText, { color: theme.textSecondary }]}>
              Nenhum evento hoje
            </ThemedText>
          </View>
        ) : (
          tasksForSelectedDate.map((task, index) => {
            const category = categories.find((cat) => cat.id === task.category);
            return (
              <TaskCard
                key={task.id}
                task={task}
                category={category}
                onPress={() => handleTaskPress(task.id)}
                onToggleComplete={() => handleToggleComplete(task.id)}
                onDelete={() => handleDeleteTask(task.id)}
                index={index}
              />
            );
          })
        )}
      </View>

      <Pressable
        style={[styles.fab, { backgroundColor: theme.primary }]}
        onPress={handleAddTask}
      >
        <Feather name="plus" size={28} color="#fff" />
      </Pressable>
    </ScreenScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  headerButton: {
    padding: Spacing.sm,
    marginRight: Spacing.sm,
  },
  taskSection: {
    paddingBottom: Spacing["5xl"],
  },
  dateTitle: {
    fontSize: 20,
    fontWeight: "600",
    marginBottom: Spacing.lg,
  },
  emptyState: {
    padding: Spacing["4xl"],
    borderRadius: BorderRadius.sm,
    alignItems: "center",
    justifyContent: "center",
    gap: Spacing.lg,
  },
  emptyText: {
    fontSize: 16,
  },
  fab: {
    position: "absolute",
    bottom: Spacing["5xl"] + Spacing["2xl"],
    right: Spacing["2xl"],
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
});
