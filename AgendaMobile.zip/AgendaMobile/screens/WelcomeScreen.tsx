import React, { useEffect } from "react";
import { View, StyleSheet, Pressable, Image } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { Feather } from "@expo/vector-icons";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius } from "@/constants/theme";
import { RootStackParamList } from "@/navigation/RootStackNavigator";
import { storage } from "@/utils/storage";
import { useSafeAreaInsets } from "react-native-safe-area-context";

type WelcomeScreenProp = NativeStackNavigationProp<RootStackParamList, "Welcome">;

export default function WelcomeScreen() {
  const navigation = useNavigation<WelcomeScreenProp>();
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();

  useEffect(() => {
    checkFirstLaunch();
  }, []);

  const checkFirstLaunch = async () => {
    const isFirstLaunch = await storage.isFirstLaunch();
    if (!isFirstLaunch) {
      navigation.replace("Main");
    }
  };

  const handleNavigateToCalendar = () => {
    navigation.replace("Main");
  };

  return (
    <ThemedView style={[styles.container, { paddingTop: insets.top + Spacing.xl, paddingBottom: insets.bottom + Spacing.xl }]}>
      <View style={styles.content}>
        <View style={styles.logoContainer}>
          <Image
            source={require("@/assets/images/icon.png")}
            style={styles.logo}
            resizeMode="contain"
          />
        </View>

        <View style={styles.buttonContainer}>
          <Pressable
            style={({ pressed }) => [
              styles.button,
              { backgroundColor: theme.backgroundSecondary },
              pressed && styles.buttonPressed,
            ]}
            onPress={handleNavigateToCalendar}
          >
            <Feather name="calendar" size={24} color={theme.primary} />
            <ThemedText style={styles.buttonText}>Calendário</ThemedText>
          </Pressable>

          <Pressable
            style={({ pressed }) => [
              styles.button,
              { backgroundColor: theme.backgroundSecondary },
              pressed && styles.buttonPressed,
            ]}
            onPress={handleNavigateToCalendar}
          >
            <Feather name="settings" size={24} color={theme.primary} />
            <ThemedText style={styles.buttonText}>Configurações</ThemedText>
          </Pressable>
        </View>

        <ThemedText style={[styles.version, { color: theme.textSecondary }]}>
          Versão 2.0.0
        </ThemedText>
      </View>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: Spacing["2xl"],
  },
  logoContainer: {
    marginBottom: Spacing["5xl"],
  },
  logo: {
    width: 200,
    height: 200,
  },
  buttonContainer: {
    width: "100%",
    gap: Spacing.lg,
  },
  button: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: Spacing.lg,
    paddingHorizontal: Spacing["2xl"],
    borderRadius: BorderRadius.sm,
    gap: Spacing.md,
  },
  buttonPressed: {
    opacity: 0.7,
  },
  buttonText: {
    fontSize: 16,
    fontWeight: "600",
  },
  version: {
    position: "absolute",
    bottom: Spacing["2xl"],
    fontSize: 14,
  },
});
