import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { Task, Category, UserSettings, DEFAULT_CATEGORIES, DEFAULT_SETTINGS } from "@/types";
import { storage } from "@/utils/storage";

interface AppContextType {
  tasks: Task[];
  categories: Category[];
  settings: UserSettings;
  addTask: (task: Omit<Task, "id" | "createdAt" | "completed" | "archived">) => Promise<void>;
  updateTask: (id: string, task: Partial<Task>) => Promise<void>;
  deleteTask: (id: string) => Promise<void>;
  toggleTaskComplete: (id: string) => Promise<void>;
  addCategory: (category: Omit<Category, "id">) => Promise<void>;
  updateCategory: (id: string, category: Partial<Category>) => Promise<void>;
  updateSettings: (settings: Partial<UserSettings>) => Promise<void>;
  isLoading: boolean;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [categories, setCategories] = useState<Category[]>(DEFAULT_CATEGORIES);
  const [settings, setSettings] = useState<UserSettings>(DEFAULT_SETTINGS);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [loadedTasks, loadedCategories, loadedSettings] = await Promise.all([
        storage.getTasks(),
        storage.getCategories(),
        storage.getSettings(),
      ]);
      
      setTasks(loadedTasks);
      setCategories(loadedCategories);
      setSettings(loadedSettings);
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const addTask = async (taskData: Omit<Task, "id" | "createdAt" | "completed" | "archived">) => {
    const newTask: Task = {
      ...taskData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      completed: false,
      archived: false,
    };
    const updatedTasks = [...tasks, newTask];
    setTasks(updatedTasks);
    await storage.saveTasks(updatedTasks);
  };

  const updateTask = async (id: string, taskData: Partial<Task>) => {
    const updatedTasks = tasks.map((task) =>
      task.id === id ? { ...task, ...taskData } : task
    );
    setTasks(updatedTasks);
    await storage.saveTasks(updatedTasks);
  };

  const deleteTask = async (id: string) => {
    const updatedTasks = tasks.filter((task) => task.id !== id);
    setTasks(updatedTasks);
    await storage.saveTasks(updatedTasks);
  };

  const toggleTaskComplete = async (id: string) => {
    const updatedTasks = tasks.map((task) =>
      task.id === id ? { ...task, completed: !task.completed } : task
    );
    setTasks(updatedTasks);
    await storage.saveTasks(updatedTasks);
  };

  const addCategory = async (categoryData: Omit<Category, "id">) => {
    const newCategory: Category = {
      ...categoryData,
      id: Date.now().toString(),
    };
    const updatedCategories = [...categories, newCategory];
    setCategories(updatedCategories);
    await storage.saveCategories(updatedCategories);
  };

  const updateCategory = async (id: string, categoryData: Partial<Category>) => {
    const updatedCategories = categories.map((cat) =>
      cat.id === id ? { ...cat, ...categoryData } : cat
    );
    setCategories(updatedCategories);
    await storage.saveCategories(updatedCategories);
  };

  const updateSettings = async (settingsData: Partial<UserSettings>) => {
    const updatedSettings = { ...settings, ...settingsData };
    setSettings(updatedSettings);
    await storage.saveSettings(updatedSettings);
  };

  return (
    <AppContext.Provider
      value={{
        tasks,
        categories,
        settings,
        addTask,
        updateTask,
        deleteTask,
        toggleTaskComplete,
        addCategory,
        updateCategory,
        updateSettings,
        isLoading,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error("useApp must be used within AppProvider");
  }
  return context;
};
